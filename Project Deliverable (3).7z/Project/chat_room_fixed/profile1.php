<?php require_once("includes/connection.php"); ?>
<?php include('login.php'); ?>
<?php
if (isset($_POST['submit'])){
  if ($_COOKIE['member_name']) {
      $username = $_COOKIE['member_name'];
      $txt= $_POST['chat'];
      $query="INSERT into messages(username,message) Values ('$username','$txt')";
      mysqli_query($connection,$query);
      //echo "<meta http-equiv='refresh' content='10;url=profile1.php'>";
  }
}

?>

<!DOCTYPE html>
<html >
<head>
<title>Chat Widget</title>
<link rel="stylesheet" href="css/style1.css">
<link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css'>
</head>
<body>
<div class="container clearfix">
<div class="people-list" id="people-list">
<div class="search">
<input type="text" placeholder="search" />
<i class="fa fa-search"></i>
</div>
<ul class="list">
<li class="clearfix">
<div class="name">Secure Project</div>
<i class="fa fa-circle online"></i> online
</li>
</ul>
</div>

<div class="chat">
<div class="chat-header clearfix" >
<div class="chat-about">
<div class="chat-with">Secure Project</div>
<div class="chat-num-messages">already 1902 messages</div>
</div>
<i class="fa fa-star"></i>
</div>
<div class="chat-history">
<iframe style="border:0;" src="content.php" width="490px" height="580px" ></iframe>
</div>
<div class="chat-message clearfix">
<form action="" method="POST">
<textarea name="chat" id="message-to-send" placeholder ="Type your message" rows="3"></textarea>
<button type="submit" name="submit">Send</button>
</form>
</div>
</div>
</div>
</body>
</html>
