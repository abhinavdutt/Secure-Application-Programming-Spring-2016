<?php

define("DB_SERVER","localhost");
define("DB_USER","root");
define("DB_PASS","OtlPHP07");
define("DB_NAME","chat_room");

?>