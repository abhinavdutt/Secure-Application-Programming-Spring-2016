		</div>
		<div id="footer">Copyright 2007, Widget Corp</div>
	</body>
</html>
<?php
	// 5. Close connection
	mysqli_close($connection);
?>