<html>
	<head>
		<title>Widget Corp</title>
		<link href="stylesheets/public.css" media="all" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<div id="header">
			<h1>Widget Corp</h1>
		</div>
		<div id="main">
