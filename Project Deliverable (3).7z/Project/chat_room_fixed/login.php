<?php require_once("includes/connection.php"); ?>
<?php
if (isset($_POST['submit'])) {
if (empty($_POST['username']) || empty($_POST['password'])) {
$error = "Username or Password is invalid";
}
else
{

$username = $_POST['username'];
$password = $_POST['password'];
//remove quotes to fix sql injection
//$username = mysqli_real_escape_string($connection,$username);
//$password = mysqli_real_escape_string($connection,$password);


$query ="SELECT * FROM user where user_name='$username' AND user_pwd='$password'";
$valid = mysqli_query($connection,$query);
$rows = mysqli_num_rows($valid);

if ($rows>0) {
$iCookieTime = time() + 24*60*60*30;
setcookie("member_name", $username, $iCookieTime, '/');
$_COOKIE['member_name'] = $username;
setcookie("member_pass", $password, $iCookieTime, '/');
$_COOKIE['member_pass'] = $password;
header("Location: profile1.php");
exit;// Redirecting To Other Page
} 

else {
$error = "Username or Password is invalid";
}
mysqli_close($connection); // Closing Connection
}
}
?>

