<?php require_once("includes/connection.php"); ?>
<?php
$fetch_msgs = "SELECT * From messages;";
$rows = mysqli_query($connection,$fetch_msgs);
while($msg = mysqli_fetch_array($rows)){
echo "<meta http-equiv='refresh' content='5;url=content.php'>";
echo $msg['username'].":".htmlspecialchars($msg['message'])."</br>";
}
?>